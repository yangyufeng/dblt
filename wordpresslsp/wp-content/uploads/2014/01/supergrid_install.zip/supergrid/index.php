<?php get_header();?>

<div id="preloader-container">
	<div id="container">

		<?php if (!has_nav_menu( 'header-menu' )) { ?>
		
		<!-- ======================================
		// SUCESSFULLY INSTALLED MESSAGE
		=========================================== -->
		<div class="widget portfolio">
			<div class="entry-container span8">		   		 
			   	<div class="entry drop-shadow curved ">
			   		<!-- Portfolio Heading -->
			   		<h5 class="heading">
			   			<a href="portfolio-single.html">
			   				SUPER GRID HAS BEEN INSTALLED
			   			</a>
			   		</h5>
			   		
			   		<div class="alert alert-success">
						<strong>Congratulations!</strong> You have successfully installed the Super Grid theme. 
					</div>
					
					<div class="alert alert-info">
						Please see the "Getting Started" documentation which gives step by step information on setting up your new theme.
					</div>  
					
					<div class="alert alert-warning">
						Alternatively, You can import the auto-setup.xml to set up the basic settings.
						Don't forget to go into Appearance -> Menus and assign "Menu" to the header.
					</div>  
					
			   		<!-- Portfolio Description -->
			   		<p>This message will automatically disappear when you have followed all the setup instructions.</p>
			   		
			   		<div class="stripes"></div>
				</div>			
			</div>
		</div>
		<?php } ?>	
		<?php while ( have_posts() ) : the_post(); ?> 
		
			
			<?php $custom = get_post_custom(); ?>
			<?php $my_terms = get_the_terms( $post->ID, 'Skills' ); ?>
			<div class="widget <?php if (!get_field('page_filter')) { echo 'blog'; } ?> <?php the_field('page_filter') ?> <?php if (is_sticky() == true) { echo 'widget-dark'; } ?>
			
			<?php 
				foreach(get_the_category() as $category) {
					echo $category->slug . ' ';
				} 
			?> 
			<?php 
				if( $my_terms && !is_wp_error( $my_terms ) ) {
					foreach( $my_terms as $term ) {
						echo $term->slug . ' ';
					}
				} 
		    ?> <?php if (get_field('column_size')) { ?> span<?php the_field('column_size'); } else { echo 'span4'; } ?>">
			
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				
				<?php if( get_field('featured_stamp') ) { ?>
				<div class="featured-stamp">
					<p>FEATURED</p>
				</div>	
				<?php } ?>
					

				<?php if ( (get_field('post_type')) == "Image" ) { ?>	
				<!-- ======================================
				// Featured Image 
				=========================================== -->			
				<a href="<?php the_field('image') ?>" class="fancybox entry-image">
					<span class="entry-image-overlay"></span>
					<img src="<?php the_field('image') ?>" alt="" />
				</a>
				<?php } ?>
					
				<?php if ( (get_field('post_type')) == "Slider" ) { ?>	
				<!-- ======================================
				// Slider
				=========================================== -->
						
				<div class="widget-slider">
					<div class="flexslider">
						<ul class="slides">
							
							<?php while(has_sub_field('slider_images')) { ?>
				    		<li>
				    			<div class="entry-image">
				    				<a href="<?php the_sub_field('slider_image'); ?>" class="fancybox">
				    					<span class="entry-image-overlay"></span>
				    					<img src="<?php the_sub_field('slider_image'); ?>" alt="" />
				    				</a>
				    			</div>
							</li>
							<?php } ?>
				
						</ul>
					</div>
				</div>		
				<?php } ?>
										
				<?php if ( (get_field('post_type')) == "Tabs" ) { ?>	
				<!-- ======================================
				// TABS
				=========================================== -->
					
				<!-- Tab Buttons -->
				<ul class="tabs" id="myTab-<?php echo get_the_ID(); ?>">
					<?php while(has_sub_field('tabs')) { ?>
					<li class="<?php if( get_sub_field('tab_active') ) { ?>active<?php } ?> drop-shadow curved-small"><a href="#<?php the_sub_field('tab_title'); ?>"><?php the_sub_field('tab_title'); ?></a></li>						
					<?php } ?>
				</ul>
					 
				<!-- Tab Content -->
				<div class="drop-shadow curved">
					<div class="tab-content">
					
						<?php while(has_sub_field('tabs')) { ?>
						<!-- Tab Content (Home) -->
						<div class="tab-pane <?php if( get_sub_field('tab_active') ) { ?>active<?php } ?>" id="<?php the_sub_field('tab_title'); ?>">
							<div class="row-fluid">
								<?php the_sub_field('tab_content'); ?>
							</div>
							<div class="stripes"></div>
						</div>
						<?php } ?>
												
					</div>
				</div>
					
				<script>
				$('#myTab-<?php echo get_the_ID(); ?> a').click(function (e) {
					e.preventDefault();
					$(this).tab('show');
				})
				</script>						
				<?php } ?>
					
				<?php if ( (get_field('post_type')) == "Audio" ) { ?>
				<!-- ======================================
				// AUDIO
				=========================================== --> 
				<div id="jquery_jplayer_<?php echo get_the_ID(); ?>" class="jp-jplayer"></div>
					
					<div id="jp_container_<?php echo get_the_ID(); ?>">
					<div class="jplayer-audio-poster">
						<img id="jp_poster_<?php echo get_the_ID(); ?>" src="<?php the_field("audio_image"); ?>">
					</div>
						<div class="jp-type-playlist">
							<div class="jp-gui jp-interface">
								<ul class="jp-controls">
									<li><a href="javascript:;" class="jp-previous" tabindex="1">previous</a></li>
									<li><a href="javascript:;" class="jp-play" tabindex="1">play</a></li>
									<li><a href="javascript:;" class="jp-pause" tabindex="1">pause</a></li>
									<li><a href="javascript:;" class="jp-next" tabindex="1">next</a></li>
									<li><a href="javascript:;" class="jp-stop" tabindex="1">stop</a></li>
									<li><a href="javascript:;" class="jp-mute" tabindex="1" title="mute">mute</a></li>
									<li><a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute">unmute</a></li>
									<li><a href="javascript:;" class="jp-volume-max" tabindex="1" title="max volume">max volume</a></li>
								</ul>
								<div class="jp-progress">
									<div class="jp-seek-bar">
										<div class="jp-play-bar"></div>
									</div>
								</div>
								<div class="jp-volume-bar">
									<div class="jp-volume-bar-value"></div>
								</div>
								<div class="jp-time-holder">
									<div class="jp-current-time"></div>
									<div class="jp-duration"></div>
								</div>
								<ul class="jp-toggles">
									<li><a href="javascript:;" class="jp-shuffle" tabindex="1" title="shuffle">shuffle</a></li>
									<li><a href="javascript:;" class="jp-shuffle-off" tabindex="1" title="shuffle off">shuffle off</a></li>
									<li><a href="javascript:;" class="jp-repeat" tabindex="1" title="repeat">repeat</a></li>
									<li><a href="javascript:;" class="jp-repeat-off" tabindex="1" title="repeat off">repeat off</a></li>
								</ul>
							</div>
						</div>
					
					</div><!-- .jp-audio -->
		
					<script type="text/javascript">
					     $(document).ready(function(){
					       $("#jquery_jplayer_<?php echo get_the_ID(); ?>").jPlayer({
					         ready: function () {
					           $(this).jPlayer("setMedia", {
					             m4a: "<?php if (get_field('audio_upload')) { the_field('audio_upload'); } else { the_field('audio_url'); } ?>",
					           });
					         },
					         play: function() { // To avoid both jPlayers playing together.
						         $(this).jPlayer("pauseOthers");
								},
					         cssSelectorAncestor: '#jp_container_<?php echo get_the_ID(); ?>',
					         swfPath: "http://www.jplayer.org/latest/js/Jplayer.swf",
					         supplied: "m4a",
					       });
					     });
					 </script>
					<?php } ?>
					
					<?php if ( (get_field('post_type')) == "Video" ) { ?>
					<?php if (!get_field('video_embed')) { ?>	
					<!-- ======================================
					// VIDEO
					=========================================== --> 
					<div id="jquery_jplayer_<?php echo get_the_ID(); ?>" class="jp-jplayer"></div>
					
					<div id="jp_container_<?php echo get_the_ID(); ?>">
						<div class="jp-type-playlist">
							<div class="jp-video-play">
							</div>
							<div class="jp-gui jp-interface">
								
								<ul class="jp-controls">
									<li><a href="javascript:;" class="jp-previous" tabindex="1">previous</a></li>
									<li><a href="javascript:;" class="jp-play" tabindex="1">play</a></li>
									<li><a href="javascript:;" class="jp-pause" tabindex="1">pause</a></li>
									<li><a href="javascript:;" class="jp-next" tabindex="1">next</a></li>
									<li><a href="javascript:;" class="jp-stop" tabindex="1">stop</a></li>
									<li><a href="javascript:;" class="jp-mute" tabindex="1" title="mute">mute</a></li>
									<li><a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute">unmute</a></li>
									<li><a href="javascript:;" class="jp-volume-max" tabindex="1" title="max volume">max volume</a></li>
								</ul>
								<div class="jp-progress">
									<div class="jp-seek-bar">
										<div class="jp-play-bar"></div>
									</div>
								</div>
								<div class="jp-volume-bar">
									<div class="jp-volume-bar-value"></div>
								</div>
								<div class="jp-time-holder">
									<div class="jp-current-time"></div>
									<div class="jp-duration"></div>
								</div>
								<ul class="jp-toggles">
									<li><a href="javascript:;" class="jp-shuffle" tabindex="1" title="shuffle">shuffle</a></li>
									<li><a href="javascript:;" class="jp-shuffle-off" tabindex="1" title="shuffle off">shuffle off</a></li>
									<li><a href="javascript:;" class="jp-repeat" tabindex="1" title="repeat">repeat</a></li>
									<li><a href="javascript:;" class="jp-repeat-off" tabindex="1" title="repeat off">repeat off</a></li>
								</ul>
							</div>
						</div>
					
					</div><!-- .jp-audio -->
		
					<script type="text/javascript">
					     $(document).ready(function(){
					       $("#jquery_jplayer_<?php echo get_the_ID(); ?>").jPlayer({
					         ready: function () {
					           $(this).jPlayer("setMedia", {
					              m4v: "<?php if (get_field('video_upload')) { the_field('video_upload'); } else { the_field('video_url'); } ?>",
					              poster: "<?php the_field("video_poster"); ?>"
					           });
					         },
					         play: function() { // To avoid both jPlayers playing together.
						         $(this).jPlayer("pauseOthers");
								},
					         cssSelectorAncestor: '#jp_container_<?php echo get_the_ID(); ?>',
					         swfPath: "http://www.jplayer.org/latest/js/Jplayer.swf",
					         supplied: "m4v",
					         size: { width: "100%", height: "<?php the_field('video_height'); ?>"}
					       });
					     });
					 </script>
					<?php } ?>
					<?php if (get_field('video_embed')) { ?>
					<div class="entry-video">
						<?php the_field('video_embed'); ?>
					</div>
					<?php } ?>
					<?php } ?>	
				
					<?php if ( (get_field('post_type')) == "Social") { ?>
					<!-- ======================================
					// SOCIAL
					=========================================== -->
						<?php if (get_field('social_type') == 'Twitter') { ?>
					    <!-- Le twitter
					    ================================================== -->
					    <!-- Script to make sure everything loads -->
					    <script type='text/javascript'>
					    jQuery(function($){
					        $(".tweet_<?php echo get_the_ID(); ?>").tweet({
					            username: "<?php the_field('twitter_username'); ?>",
					            join_text: "auto",
					            avatar_size: 32,
					            count: <?php the_field('twitter_count'); ?>,
					            auto_join_text_default: "we said, ",
					            auto_join_text_ed: "we ",
					            auto_join_text_ing: "we were ",
					            auto_join_text_reply: "we replied to ",
					            auto_join_text_url: "we were checking out ",
					            loading_text: "loading tweets... "
					        });
					    });
					    </script> 	
						<div class="tweet-container drop-shadow curved">
							<div class="tweet_<?php echo get_the_ID(); ?>"></div> 
							<div class="stripes"></div>
						</div>	
						<?php } ?>					
					<?php } ?>
					
					<?php if ( (get_field('post_type')) == "Quote") { ?>
					<!-- ======================================
					// QUOTE
					=========================================== -->
					<div class="entry-quote">
						<blockquote><p><?php the_field('the_quote'); ?></p></blockquote>
					</div>				
					<?php } ?>
				   		
					<?php if ( (get_field('post_type') !== "Social") && (get_field('post_type') !== "Tabs")) { ?>
				   	<!-- ======================================
				   	// PLAIN
				   	=========================================== --> 	
				   	<div class="entry drop-shadow curved">
				   		<!-- Portfolio Heading -->
				   		<?php if (get_the_title()) { ?>
				   		<h5 class="heading">
				   			<a href="<?php the_permalink(); ?>">
				   				<?php the_title(); ?>
				   			</a>
				   		</h5>

				   		<!-- Icons -->
				   		<?php if(get_field('post_icons') && (get_field('post_type') !== "Slider")) { ?>
				   		<ul class="social">
					   		<?php while(has_sub_field('post_icons')) { ?>
							<li class="social-button-team right"><a href="<?php the_sub_field('post_icon_url')?>" rel="alternate" data-original-title="<?php the_sub_field('post_icon_title')?>"><img height="20" src="<?php echo get_template_directory_uri(); ?>/img/icons/<?php the_sub_field('post_icon')?>" alt="" /></a></li>
							<?php } ?>
					   	</ul>
					   	<?php } ?>
					   	<?php } ?>
				   		
				   		<!-- Portfolio Description -->
				   		<?php if (get_field('excerpt') == "Full") {?>
				   		<?php the_content(); ?>
				   		<?php } ?>
				   		
				   		<?php if (get_field('excerpt') == "Excerpt") {?>
				   		<?php the_excerpt(); ?>
				   		<?php } ?>
				   		
				   		<?php if(get_field('post_footer')) { ?>
			   		 	<ul class="entry-footer">
			   		 		<?php if( in_array( 'Timestamp', get_field('post_footer'))) { ?>
			   		 			<li class="left"> <?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?> </li>
			   		 		<?php } ?>
			   		 		
			   		 		<?php if( in_array( 'Comments', get_field('post_footer'))) { ?>
			   		 			<li class="right no-margin"><a href="<?php the_permalink(); ?>"><div class="icon comment"></div> <?php comments_number('0','1','%'); ?></a></li>
			   		 		<?php } ?>
			   		 		<?php if( in_array( 'Like', get_field('post_footer'))) { ?>
			   		 			<?php echo getPostLikeLink(get_the_ID());?>    
			   		 		<?php } ?>
			   		 	</ul>
				   		<?php } ?>
				   		<span class="stripes"></span>
					</div>	
					<?php } ?>									
				</div>
			</div>
		<?php endwhile; ?>
		
		<!-- ======================================
	   	// CONTACT WIDGET
	   	=========================================== --> 
		
		<div class="widget widget-dark contact">
			<div class="span-full">	
				<div class="entry-container span4 right">
					<div class="entry drop-shadow curved">
						<h4 class="heading">EMAIL US</h4>
						<div class="contact-alerts">
						</div>
						<form id="contact" action="contact.php">
							<div class="row-fluid">
								<div class="span12">
									<input id="name" type="text" value="" placeholder="Name" name="name">
								</div>		
							</div>			
							
							<div class="row-fluid">
								<div class="span12">
									<input id="email" type="text" value="" placeholder="Email" name="email">
								</div>
							</div>
							
							<div class="row-fluid">
								<div class="span12">
									<textarea id="message" required="" rows="6" placeholder="Message" name="message"></textarea>
								</div>
							</div>
							<div class="row-fluid">
								<div class="span12">
									<div class="submit">
										<img src="<?php echo get_template_directory_uri(); ?>/img/icon_submit.png" alt=""/>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>
<?php paginate_links(); ?>
<?php get_footer(); ?>   