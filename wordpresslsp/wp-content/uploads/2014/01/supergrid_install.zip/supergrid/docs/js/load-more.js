if(document.location.toString().indexOf('#filter=.blog')!=-1){

	$("#page_nav").css("display","block");
	
} else {

	$("#page_nav").css("display","none");

}