Thank you for purchasing our theme!
Please open the "Getting Started" PDF for instructions on how you can quickly set up this theme.

If you require further help, please email us using the contact form available on our profile page.


http://themeforest.net/user/Jaynesh