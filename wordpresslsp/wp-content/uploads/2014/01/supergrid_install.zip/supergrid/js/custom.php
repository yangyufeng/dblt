<?php
if(file_exists('../../../../wp-load.php')) :
		include '../../../../wp-load.php';
	else:
		include '../../../../../wp-load.php';
	endif;  
?>

// JQUERY (flexslider)
$(document).ready(function() {
	"use strict";
	$('.widget-slider .flexslider').flexslider({
		animation: "<?php if (get_field('slider_animation', 'option')) { the_field('slider_animation', 'option'); } else { echo 'slide'; } ?>",
		slideshow: "<?php if (get_field('slider_slideshow', 'option')) { the_field('slider_slideshow', 'option'); } else { echo 'false';} ?>",
		slideshowSpeed: <?php if (get_field('slideshow_speed', 'option')) {the_field('slideshow_speed', 'option'); } else { echo '800'; } ?>,
		animationSpeed: <?php if (get_field('slider_animation_speed', 'option')) {the_field('slider_animation_speed', 'option'); } else { echo '600'; } ?>,  
		easing: "swing", 
		directionNav: false 
		});
	});

// Le preloader
$(window).load(function() { // makes sure the whole site is loaded
"use strict";
	$("#status").fadeOut(); // will first fade out the loading animation
	$("#preloader").delay(350).fadeOut("slow"); // will fade out the white DIV that covers the website.
	$("#preloader-container").css("position","static");  
});
 
// Google Maps
function initialize() {
	var styles = [ { "stylers": [ { "visibility": "on" }, { "saturation": -100 }, { "gamma": 1 } ] },{ } ];
	
	var myLatlng = new google.maps.LatLng(<?php if (get_field('latitude', 'option')) {the_field('latitude', 'option'); } else { echo '41.385'; } ?>,<?php if (get_field('longitude', 'option')) {the_field('longitude', 'option'); } else { echo '2.169'; } ?>);
    var mapOptions = {
	    zoom: 15,
	    mapTypeId: google.maps.MapTypeId.ROADMAP,
	    disableDefaultUI: true,
	    draggable: false,
	    scrollwheel: false,
	    center: myLatlng,
	};
	
	var map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
    map.setOptions({styles: styles});
    
	var image = '<?php the_field('bubble', 'option'); ?>';
	var marker = new google.maps.Marker({
	    position: myLatlng,
	    map: map,
	   icon: image,
	});
	
}
 
// CONTACT FORM
$('.submit').click(function() {
	"use strict";
	var name = $("#name").val();
	var email = $("#email").val();
	var message = $("#message").val();
	
	var dataString = 'name='+ name + '&email=' + email + '&message=' + message;
	
	$.ajax({  
		type: "POST",  
		url: "<?php echo get_template_directory_uri(); ?>/contact.php",  
		data: dataString,  
		success:  function (html) { 
			if (html === "invalid_email ") {
				$('.contact-alerts').empty();
				$('.contact-alerts').append('<div id="email-error" class="alert alert-error">This email is invalid!</div>');
				} else if (html === "success ") {
					$('.contact-alerts').empty();
					$('.contact-alerts').append('<div id="email-success" class="alert alert-success">Your email has been sent!</div>');
				} else if (html === "error ") {
					$('.contact-alerts').empty();
					$('.contact-alerts').append('<div id="email-error" class="alert alert-error">Please fill out all the fields!</div>');
				}
			}  
		});  
	});

// JQUERY (tooltips)
$("[rel=alternate]").tooltip()

// JQUERY (hash)
$(window).bind( 'hashchange', function( event ) {
  $.getScript("<?php echo get_template_directory_uri(); ?>/js/load-more.php")
});

// JQUERY (fancy)
$(document).ready(function() {
	$(".fancybox").fancybox({
		helpers : {
		        overlay : {
		            locked : false
		        }
		    },
		    
		    padding: ['5px', '5px', '5px', '5px']
	});
});

// JQUERY (isotope)
$(window).load(function(){

	$.Isotope.prototype._getCenteredMasonryColumns = function() {
		this.width = this.element.width();
		var parentWidth = this.element.parent().width();
      
		// i.e. options.masonry && options.masonry.columnWidth
		var colW = this.options.masonry && this.options.masonry.columnWidth ||
		// or use the size of the first item
		this.$filteredAtoms.outerWidth(true) ||
		// if there's no items, use size of container
		parentWidth;
		
		var cols = Math.floor( parentWidth / colW );
		cols = Math.max( cols, 1 );
  
		// i.e. this.masonry.cols = ....
		this.masonry.cols = cols;
		// i.e. this.masonry.columnWidth = ...
		this.masonry.columnWidth = colW;
	};
	
	$.Isotope.prototype._masonryReset = function() {
		// layout-specific props
		this.masonry = {};
		// FIXME shouldn't have to call this again
		this._getCenteredMasonryColumns();
		var i = this.masonry.cols;
		this.masonry.colYs = [];
		while (i--) {
			this.masonry.colYs.push( 0 );
		}
	};
	
	$.Isotope.prototype._masonryResizeChanged = function() {
		var prevColCount = this.masonry.cols;
		// get updated colCount
		this._getCenteredMasonryColumns();
		return ( this.masonry.cols !== prevColCount );
	};
	
	$.Isotope.prototype._masonryGetContainerSize = function() {
		var unusedCols = 0,
		i = this.masonry.cols;
		// count unused columns
		while ( --i ) {
			if ( this.masonry.colYs[i] !== 0 ) {
				break;
			}
			unusedCols++;
		}
      
		return {
			height : Math.max.apply( Math, this.masonry.colYs ),
			// fit container to columns that have been used;
			width : (this.masonry.cols - unusedCols) * this.masonry.columnWidth
		};
	};
    
	// Check if Mobile or Tablet device  
	function is_touch_device() {
		return !!('ontouchstart' in window) // works on most browsers 
		|| !!('onmsgesturechange' in window); // works on ie10
	};
    
	// If touch device, disable transforms.
	if (is_touch_device() && $(window).width() < 800) { 
		var bubu = {
			animationEngine: 'best-available',
			filter: '<?php $str = get_field('homepage', 'option');
$str = '.' . implode(' .',explode(' ',$str));
if (get_field('homepage', 'option')) { echo $str; } else { echo ".portfolio"; }
?>',
			sortBy: 'original-order',
			sortAscending: true,
			transformsEnabled: false,
			layoutMode: 'masonry'
		};
		
     } else {
	     var bubu = {
		     animationEngine: 'best-available',
		     filter: '<?php $str = get_field('homepage', 'option');
$str = '.' . implode(' .',explode(' ',$str));
if (get_field('homepage', 'option')) { echo $str; } else { echo ".portfolio"; }
?>',
			sortBy: '<?php if (get_field('sort_by', 'option') == "DateTime") { echo 'original-order'; } else { echo 'random'; } ?>',
			sortAscending: true,
			transformsEnabled: true,
			layoutMode: 'masonry',
			animationOptions: {
				queue: false,
				easing: 'linear',
				duration: <?php if (get_field('grid_animation_duration', 'option')) {the_field('grid_animation_duration', 'option');} else { echo '5000'; } ?>
			},
		};
	}
	
	// Settings for the grid
    $(function(){
	    var $container = $('#container'),
	    // object that will keep track of options
	    isotopeOptions = {},
	    // defaults, used if not explicitly set in hash
	    defaultOptions = bubu;
	    
	    var setupOptions = $.extend( {}, defaultOptions, {
		    itemSelector : '.widget',
		    masonry: {
			    gutterWidth: 50,
			    columnWidth: 1,
			   },
		});
		
    
	// set up Isotope
	$container.isotope( setupOptions );
	var $optionSets = $('nav').find('ul'),
	isOptionLinkClicked = false;
  
	// switches selected class on buttons
	function changeSelectedLink( $elem ) {
		// remove selected class on previous item
		$elem.parents().find('.selected').removeClass('selected');
		// set selected class on new item
		$elem.addClass('selected');
	}
	

	$container.infinitescroll({
        navSelector  : '#page_nav',    // selector for the paged navigation 
        nextSelector : '#page_nav a',  // selector for the NEXT link (to page 2)
        itemSelector : '<?php $str = get_field('homepage', 'option');
$str = '.' . implode(' .',explode(' ',$str));
echo $str;
?>',     // selector for all items you'll retrieve
        behavior: 'twitter',
        loading: {
            finishedMsg: '',
            img: ''
          }
        },
        // call Isotope as a callback
        function(newElements) {
  var $newElems = $(newElements);
  $newElems.imagesLoaded(function(){
    $container.isotope('appended', $newElems );
  });
	$("#page_nav a").css("background-image","url(<?php echo get_template_directory_uri(); ?>/img/icon_cross.png)");
	$.getScript("<?php echo get_template_directory_uri(); ?>/js/post-like.js");
}
      );

	    
	$optionSets.find('a').click(function(){
		var $this = $(this);
		// don't proceed if already selected
		if ( $this.hasClass('selected') ) {
			return;
		}
		changeSelectedLink( $this );
		// get href attr, remove leading #
		var href = $this.attr('href').replace( /^#/, '' ),
		// convert href into object
		// i.e. 'filter=.inner-transition' -> { filter: '.inner-transition' }
		option = $.deparam( href, true );
		// apply new option to previous
		$.extend( isotopeOptions, option );
		// set hash, triggers hashchange on window
		$.bbq.pushState( isotopeOptions );
		isOptionLinkClicked = true;
      
		if ($(window).width() <= 480) {  
			$('#nav-collapse').removeClass('in');
			$('#nav-collapse').css('height','0');
		}
		// Reloads script on filter.
		$.getScript("<?php echo get_template_directory_uri(); ?>/js/load-more.php");
		$.getScript("<?php echo get_template_directory_uri(); ?>/js/post-like.js");
        return false;
    });
    

    var hashChanged = false;
    $(window).bind( 'hashchange', function( event ){
	    // get options object from hash
	    var hashOptions = window.location.hash ? $.deparam.fragment( window.location.hash, true ) : {},
	    // do not animate first call
	    aniEngine = hashChanged ? 'best-available' : 'none',
	    // apply defaults where no option was specified
	    options = $.extend( {}, defaultOptions, hashOptions, { animationEngine: aniEngine } );
	    // apply options from hash
	    $container.isotope( options );
	    // save options
	    isotopeOptions = hashOptions;
	    
	    // if option link was not clicked
        // then we'll need to update selected links
        if ( !isOptionLinkClicked ) {
	        // iterate over options
	        var hrefObj, hrefValue, $selectedLink;
	        for ( var key in options ) {
		        hrefObj = {};
		        hrefObj[ key ] = options[ key ];
		        // convert object into parameter string
		        // i.e. { filter: '.inner-transition' } -> 'filter=.inner-transition'
		        hrefValue = $.param( hrefObj );
		        // get matching link
		        $selectedLink = $optionSets.find('a[href="#' + hrefValue + '"]');
		        changeSelectedLink( $selectedLink );
		    }
		}
		
		isOptionLinkClicked = false;
		hashChanged = true;
	})
	
	
    // trigger hashchange to capture any hash data on init
    .trigger('hashchange');
    });
    });

<?php 

/*-----------------------------------------------------------------------------------*/
/*	Google Analytics Code
/*-----------------------------------------------------------------------------------*/

$google_analytics = get_field('google_analytics', 'option'); 
$google_analytics = str_replace("&#039;","'",$google_analytics);
$google_analytics = str_replace("&lt;","<",$google_analytics); 
$google_analytics = str_replace("&quot;",'"',$google_analytics); 
$google_analytics = str_replace("&gt;",'>',$google_analytics); 
	    
echo $google_analytics;

?>