<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="utf-8">
    <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />  

    <!-- Fav and touch icons -->
    <?php if (get_field('apple_touch_icon', 'option')) { ?>
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php the_field('apple_touch_icon', 'option'); ?>">
    <?php } ?>
    
    <?php if (get_field('favicon', 'option')) { ?>
    <link rel="shortcut icon" href="<?php the_field('favicon', 'option'); ?>">
    <?php } ?>
    
    <?php wp_head(); ?>
    <?php wp_enqueue_style("responsive"); ?>
    <?php if ( is_user_logged_in() ) { ?>
    <style>
    body, .navigation {
	    margin-top: 28px;
    }
    body {
	    padding-top: 80px;
    }
    #info-nav {
		top: 97px;
	}
    </style>  
    <?php } ?>
    
    </head>
<body>
	
	<?php if (has_nav_menu( 'header-menu' )) { ?>
		<!-- MOBILE MENU
		================================================== -->
		<?php none_ajax_mobile_menu(); ?>
		
		<!-- DESKTOP NAVIGATION
		================================================== -->
		<?php none_ajax_menu(); ?>
	<?php } ?>
	
	<?php // style_switcher(); ?>
	
	<!-- Content
	================================================== -->
	<!-- Content starts here -->
	
	<div class="body-container">
		<div class="container">
		
			<div class="row">
				<div class="<?php column_size_offset(); ?>">
					<div class="row">
						<?php while ( have_posts() ) : the_post();  ?>
						<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="entry-container <?php column_size(); ?> margin-bottom <?php if (is_sticky() == true) { echo 'widget-dark'; } ?>">
							<?php if( get_field('featured_stamp') ) { ?>
								<div class="featured-stamp">
									<p>FEATURED</p>
								</div>	
							<?php } ?>
								
							<?php if ( (get_field('post_type')) == "Image" ) { ?>
							<!-- ======================================
							// IMAGE
							=========================================== -->
							
							<div class="entry-image">
								<a href="<?php the_field('image') ?>" class="fancybox">
									<span class="entry-image-overlay"></span>
									<img src="<?php the_field('image') ?>" alt="" />
								</a>
							</div>
							<?php } ?>
							  
							<?php if ( (get_field('post_type')) == "Slider" ) { ?>	
							<!-- ======================================
							// Slider
							=========================================== -->		
							<div class="widget-slider">
								<div class="flexslider">
									<ul class="slides">
										
										<?php while(has_sub_field('slider_images')) { ?>
							    		<li>
							    			<div class="entry-image">
							    				<a href="<?php the_sub_field('slider_image'); ?>" class="fancybox">
							    					<span class="entry-image-overlay"></span>
							    					<img src="<?php the_sub_field('slider_image'); ?>" alt="" />
							    				</a>
							    			</div>
										</li>
										<?php } ?>
							
									</ul>
								</div>
							</div>		
							<?php } ?>
							
							<?php if ( (get_field('post_type')) == "Quote") { ?>
							<!-- ======================================
							// QUOTE
							=========================================== -->
							<div class="entry-quote">
								<blockquote><p><?php the_field('the_quote'); ?></p></blockquote>
							</div>			
							<?php } ?>
							  
							<?php if ( (get_field('post_type')) == "Audio" ) { ?>
							<!-- ===========================================
							// AUDIO
							=========================================== -->
							<div id="jquery_jplayer_<?php echo get_the_ID(); ?>" class="jp-jplayer"></div>
							
							<div id="jp_container_<?php echo get_the_ID(); ?>">
							<div class="jplayer-audio-poster">
								<img id="jp_poster_<?php echo get_the_ID(); ?>" src="<?php the_field("audio_image"); ?>">
							</div>
								<div class="jp-type-playlist">
									<div class="jp-gui jp-interface">
										<ul class="jp-controls">
											<li><a href="javascript:;" class="jp-previous" tabindex="1">previous</a></li>
											<li><a href="javascript:;" class="jp-play" tabindex="1">play</a></li>
											<li><a href="javascript:;" class="jp-pause" tabindex="1">pause</a></li>
											<li><a href="javascript:;" class="jp-next" tabindex="1">next</a></li>
											<li><a href="javascript:;" class="jp-stop" tabindex="1">stop</a></li>
											<li><a href="javascript:;" class="jp-mute" tabindex="1" title="mute">mute</a></li>
											<li><a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute">unmute</a></li>
											<li><a href="javascript:;" class="jp-volume-max" tabindex="1" title="max volume">max volume</a></li>
										</ul>
										<div class="jp-progress">
											<div class="jp-seek-bar">
												<div class="jp-play-bar"></div>
											</div>
										</div>
										<div class="jp-volume-bar">
											<div class="jp-volume-bar-value"></div>
										</div>
										<div class="jp-time-holder">
											<div class="jp-current-time"></div>
											<div class="jp-duration"></div>
										</div>
										<ul class="jp-toggles">
											<li><a href="javascript:;" class="jp-shuffle" tabindex="1" title="shuffle">shuffle</a></li>
											<li><a href="javascript:;" class="jp-shuffle-off" tabindex="1" title="shuffle off">shuffle off</a></li>
											<li><a href="javascript:;" class="jp-repeat" tabindex="1" title="repeat">repeat</a></li>
											<li><a href="javascript:;" class="jp-repeat-off" tabindex="1" title="repeat off">repeat off</a></li>
										</ul>
									</div>
									<div class="jp-no-solution">
										<span>Update Required</span>
										To play the media you will need to either update your browser.
									</div>
								</div>
							
							</div><!-- .jp-audio -->
				
							<script type="text/javascript">
							     $(document).ready(function(){
							       $("#jquery_jplayer_<?php echo get_the_ID(); ?>").jPlayer({
							         ready: function () {
							           $(this).jPlayer("setMedia", {
							             mp3: "<?php if (get_field('audio_upload')) { the_field('audio_upload'); } else { the_field('audio_url'); } ?>",
							           });
							         },
							         play: function() { // To avoid both jPlayers playing together.
								         $(this).jPlayer("pauseOthers");
										},
							         cssSelectorAncestor: '#jp_container_<?php echo get_the_ID(); ?>',
							         swfPath: "http://www.jplayer.org/latest/js/Jplayer.swf",
							         supplied: "mp3",
							       });
							     });
							 </script>
							<?php } ?>
						
							<?php if ( (get_field('post_type')) == "Video" ) { ?>
					<?php if (!get_field('video_embed')) { ?>	
					<!-- ======================================
					// VIDEO
					=========================================== --> 
					<div id="jquery_jplayer_<?php echo get_the_ID(); ?>" class="jp-jplayer"></div>
					
					<div id="jp_container_<?php echo get_the_ID(); ?>">
						<div class="jp-type-playlist">
							<div class="jp-video-play">
							</div>
							<div class="jp-gui jp-interface">
								
								<ul class="jp-controls">
									<li><a href="javascript:;" class="jp-previous" tabindex="1">previous</a></li>
									<li><a href="javascript:;" class="jp-play" tabindex="1">play</a></li>
									<li><a href="javascript:;" class="jp-pause" tabindex="1">pause</a></li>
									<li><a href="javascript:;" class="jp-next" tabindex="1">next</a></li>
									<li><a href="javascript:;" class="jp-stop" tabindex="1">stop</a></li>
									<li><a href="javascript:;" class="jp-mute" tabindex="1" title="mute">mute</a></li>
									<li><a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute">unmute</a></li>
									<li><a href="javascript:;" class="jp-volume-max" tabindex="1" title="max volume">max volume</a></li>
								</ul>
								<div class="jp-progress">
									<div class="jp-seek-bar">
										<div class="jp-play-bar"></div>
									</div>
								</div>
								<div class="jp-volume-bar">
									<div class="jp-volume-bar-value"></div>
								</div>
								<div class="jp-time-holder">
									<div class="jp-current-time"></div>
									<div class="jp-duration"></div>
								</div>
								<ul class="jp-toggles">
									<li><a href="javascript:;" class="jp-shuffle" tabindex="1" title="shuffle">shuffle</a></li>
									<li><a href="javascript:;" class="jp-shuffle-off" tabindex="1" title="shuffle off">shuffle off</a></li>
									<li><a href="javascript:;" class="jp-repeat" tabindex="1" title="repeat">repeat</a></li>
									<li><a href="javascript:;" class="jp-repeat-off" tabindex="1" title="repeat off">repeat off</a></li>
								</ul>
							</div>
						</div>
					
					</div><!-- .jp-audio -->
		
					<script type="text/javascript">
					     $(document).ready(function(){
					       $("#jquery_jplayer_<?php echo get_the_ID(); ?>").jPlayer({
					         ready: function () {
					           $(this).jPlayer("setMedia", {
					              m4v: "<?php if (get_field('video_upload')) { the_field('video_upload'); } else { the_field('video_url'); } ?>",
					              poster: "<?php the_field("video_poster"); ?>"
					           });
					         },
					         play: function() { // To avoid both jPlayers playing together.
						         $(this).jPlayer("pauseOthers");
								},
					         cssSelectorAncestor: '#jp_container_<?php echo get_the_ID(); ?>',
					         swfPath: "http://www.jplayer.org/latest/js/Jplayer.swf",
					         supplied: "m4v",
					         size: { width: "100%", height: "<?php the_field('video_height'); ?>"}
					       });
					     });
					 </script>
					<?php } ?>
					<?php if (get_field('video_embed')) { ?>
					<div class="entry-video">
						<?php the_field('video_embed'); ?>
					</div>
					<?php } ?>
					<?php } ?>			 
							<div class="entry drop-shadow curved">
							  	 
							  	<!-- Portfolio Heading -->
						   		<?php if (get_the_title()) { ?>
						   		<h5 class="heading">
						   			<a href="<?php the_permalink(); ?>">
						   				<?php the_title(); ?>
						   			</a>
						   		</h5>
						   		
						   		<!-- Icons -->
						   		<?php if(get_field('post_icons') && (get_field('post_type') !== "Slider")) { ?>
						   		<ul class="social">
							   	
								   	<?php while(has_sub_field('post_icons')) { ?>	
									<li class="social-button-team right"><a href="<?php the_sub_field('post_icon_url')?>" rel="alternate" data-original-title="<?php the_sub_field('post_icon_title')?>"><img height="20" src="<?php echo get_template_directory_uri(); ?>/img/icons/<?php the_sub_field('post_icon')?>" alt="" /></a></li>
									<?php } ?>
								
							   	</ul>
							   	<?php } ?>
							   	<?php } ?>
							  	 
							   	<!-- Description -->
							  	<?php the_content(); ?>
							  	 <div class="clearboth">&nbsp;</div>
							  	<?php if(get_field('post_footer')) { ?>
						   		 <div class="entry-footer">
						   		 	<ul>
						   		 		<?php if( in_array( 'Timestamp', get_field('post_footer'))) { ?>
						   		 			<li class="left"> <?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?> </li>
						   		 		<?php } ?>
						   		 		
						   		 		<?php if( in_array( 'Comments', get_field('post_footer'))) { ?>
						   		 			<li class="right no-margin"><a href="<?php the_permalink(); ?>"><div class="icon comment"></div> <?php comments_number('0','1','%'); ?></a></li>
						   		 		<?php } ?>
						   		 		<?php if( in_array( 'Like', get_field('post_footer'))) { ?>
						   		 			<?php echo getPostLikeLink(get_the_ID());?>    
						   		 		<?php } ?>
						   		 	</ul>
						   		 </div>
						   		<?php } ?>
						   		
						   		 <div class="stripes"></div>
						   	</div>
						 </div>
						 </div>
						 <?php $args = array(
							'before'           => '<p>' . 'Pages:',
							'after'            => '</p>',
							'link_before'      => '',
							'link_after'       => '',
							'next_or_number'   => 'number',
							'nextpagelink'     => 'Next page',
							'previouspagelink' => 'Previous page',
							'pagelink'         => '%',
							'echo'             => 1
						); 
						?>
						<?php // dynamic_sidebar('my_mega_menu') ?>
						<div class="<?php column_size(); ?>">
						<?php wp_link_pages( $args ); ?>
							<div class="tag-cloud">
								 <?php  the_tags('', ' ', '<br />');  ?>
							</div>
						</div>
						<?php endwhile; ?>
		
					</div>
				</div>
				 
				 <div class="span4">
				 	<div class="row"> 
						<div class="span4">
							<h3 class="heading"><?php comments_number(); ?></h3>
						</div>
						<?php wp_list_comments(); ?>
						<?php paginate_comments_links(); ?>
						<?php comments_template(); ?>
				 	</div>
				 </div>
				 
			</div>
			
					</div>     
	</div> <!-- #container -->

<?php get_footer(); ?>  